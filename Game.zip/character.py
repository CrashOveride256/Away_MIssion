# character.py
import random

DEFAULT_HEALTH = 100
DEFAULT_ENERGY = 100
DEFAULT_ITEMS = ["Communicator", "Phaser"]
SKILL_CATEGORIES = ["phaser_combat", "diplomacy", "engineering", "science"]


class Character:
    def __init__(self, name, species, skills, items=None):
        if items is None:
            items = list(DEFAULT_ITEMS)
        self.name = name
        self.species = species
        self.skills = skills
        self.items = items
        self.health = DEFAULT_HEALTH
        self.energy = DEFAULT_ENERGY
        self.objectives = []  # New attribute to track mission objectives


def _get_random_skill_scores(seed=None):
    if seed is not None:
        random.seed(seed)
    return {skill: random.randint(5, 15) for skill in SKILL_CATEGORIES}


def create_new_character(name, species):  # Accept name and species as parameters
    if not isinstance(name, str):
        raise TypeError("name must be a string")
    if not isinstance(species, str):
        raise TypeError("species must be a string")

    skills = _get_random_skill_scores()
    print(
        f"Q: Fascinating! You are now {name}, a {species} with some basic skills in phaser combat, diplomacy, engineering, and science. Good luck… you’ll need it.")
    return Character(name, species, skills, list(DEFAULT_ITEMS))
