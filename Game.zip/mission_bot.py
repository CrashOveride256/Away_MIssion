import random
from events import skill_check  # Assuming events.py contains the skill_check function

class Mission:
    def __init__(self, mission_type):
        self.mission_type = mission_type
        self.completed = False
        self.turns_remaining = 5  # Example of a multi-turn mission

    def perform_turn(self, game_map, player_character):
        """Perform a turn, handling room events and checking mission objectives."""
        if game_map.is_objective_reached():
            if self.mission_type == "rescue":
                print("You have found the lost crew member! Mission success!")
            elif self.mission_type == "artifact":
                print("You have discovered the lost artifact! Mission success!")
            elif self.mission_type == "repair":
                print("You found the crashed shuttlecraft! Begin repairs.")
                if skill_check(player_character, "Engineering", 15):
                    print("You successfully repaired the shuttlecraft!")
                else:
                    print("You failed the repair attempt. Try again next turn.")
                    return False  # Mission is not completed yet
            self.completed = True
            return True

        # Handle room-based events
        current_room = game_map.map_grid[game_map.player_y][game_map.player_x]
        if current_room == "Enemy":
            if skill_check(player_character, "Combat", 15):
                print("You defeated the enemy!")
            else:
                print("You took damage from the enemy!")
                player_character.health -= 10
                if player_character.health <= 0:
                    print("You have been defeated!")
                    self.completed = True
                    return True

        elif current_room == "Trap":
            print("You triggered a trap! Roll a skill check to escape.")
            if skill_check(player_character, "Dexterity", 10):
                print("You successfully avoided the trap!")
            else:
                print("You took damage from the trap.")
                player_character.health -= 5

        elif current_room == "Item":
            print("You found an item! It has been added to your inventory.")
            player_character.items.append("Mystery Artifact")

        elif current_room == "Puzzle":
            print("You encountered a puzzle! Solve it to proceed.")
            if skill_check(player_character, "Intelligence", 12):
                print("You solved the puzzle and gained experience!")
                player_character.experience += 10
            else:
                print("You failed the puzzle and lost some energy.")
                player_character.energy -= 5

        # Decrease the remaining turns
        self.turns_remaining -= 1
        if self.turns_remaining <= 0:
            print("Mission failed - time ran out!")
            self.completed = True

        return self.completed

def generate_mission(mission_type):
    """Factory function to create a new Mission object based on the mission type."""
    return Mission(mission_type)
