import random

from PyQt6.QtWidgets import QMainWindow, QApplication


class GameWindow(QMainWindow):
    # Other methods remain unchanged...

    def execute_command(self, command):
        """Handle command execution."""
        self.interactive_window.append(f"Executing command: {command}")
        if command == "Create Character":
            self.create_character_gui()
        elif command == "Start Mission":
            self.start_mission()
        elif command in ["Move North", "Move South", "Move East", "Move West"]:
            self.move_player(command)
        elif command == "End Mission":
            self.interactive_window.append("Mission ended.")
            self.update_command_buttons(['Create Character', 'Start Mission', 'Explore', 'Quit'])
        elif command == "Quit":
            self.interactive_window.append("Exiting game...")
            QApplication.quit()

    def move_player(self, direction):
        """Move the player and update the map."""
        x, y = self.player_position

        if direction == "Move North" and y > 0:
            self.player_position = (x, y - 1)
        elif direction == "Move South" and y < len(self.game_map) - 1:
            self.player_position = (x, y + 1)
        elif direction == "Move East" and x < len(self.game_map[0]) - 1:
            self.player_position = (x + 1, y)
        elif direction == "Move West" and x > 0:
            self.player_position = (x - 1, y)
        else:
            self.interactive_window.append("Invalid move.")
            return

        # Check for room type after movement
        self.check_room_encounter()
        self.draw_graphical_map()
        self.interactive_window.append(f"You moved to position {self.player_position}.")

    def check_room_encounter(self):
        """Check the type of room and handle encounters."""
        x, y = self.player_position
        room_type = self.game_map[y][x]

        if room_type == "Enemy":
            self.handle_enemy_encounter()
        elif room_type == "Trap":
            self.handle_trap_encounter()
        elif room_type == "Treasure":
            self.collect_treasure()
        elif room_type == "Objective":
            self.interactive_window.append("Congratulations! You have reached the mission objective!")
            self.update_command_buttons(['Create Character', 'Start Mission', 'Explore', 'Quit'])

    def handle_enemy_encounter(self):
        """Simulate an enemy encounter with a skill check."""
        self.interactive_window.append("You encountered an enemy! Engaging in combat...")

        player_strength = self.character['skills'].get('Strength', 0)
        success_threshold = random.randint(1, 20)  # Random number between 1 and 20

        if player_strength >= success_threshold:
            self.interactive_window.append("Success! You defeated the enemy.")
        else:
            self.character['health'] -= 20  # Decrease health on failure
            self.interactive_window.append("Failure! The enemy attacked you, and you lost 20 health.")
            self.update_character_sheet()

            if self.character['health'] <= 0:
                self.interactive_window.append("You have been defeated by the enemy. Game over.")
                self.update_command_buttons(['Create Character', 'Start Mission', 'Explore', 'Quit'])

    def handle_trap_encounter(self):
        """Simulate a trap encounter with a skill check."""
        self.interactive_window.append("You triggered a trap! Trying to avoid it...")

        player_agility = self.character['skills'].get('Agility', 0)
        success_threshold = random.randint(1, 15)  # Random number between 1 and 15

        if player_agility >= success_threshold:
            self.interactive_window.append("Success! You managed to avoid the trap.")
        else:
            self.character['health'] -= 10  # Decrease health on failure
            self.interactive_window.append("Failure! The trap injured you, and you lost 10 health.")
            self.update_character_sheet()

            if self.character['health'] <= 0:
                self.interactive_window.append("You succumbed to your injuries. Game over.")
                self.update_command_buttons(['Create Character', 'Start Mission', 'Explore', 'Quit'])

    def collect_treasure(self):
        """Handle finding treasure."""
        item_found = random.choice(["Healing Potion", "Energy Crystal", "Rare Artifact"])
        self.character['items'].append(item_found)
        self.update_character_sheet()
        self.interactive_window.append(f"You found a treasure! You obtained a {item_found}.")
