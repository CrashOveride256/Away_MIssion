import random

from PyQt6.QtWidgets import QInputDialog

# Example event data structure, modify as needed for your game
event_data = {
    "trap": {
        "prompt": "You triggered a trap! Can you escape?",
        "options": {
            "1": "Attempt to disarm the trap",
            "2": "Try to avoid the trap"
        },
        "success_message": {
            "1": "You successfully disarmed the trap!",
            "2": "You managed to avoid the trap!"
        },
        "failure_message": {
            "1": "You failed to disarm the trap and took damage!",
            "2": "You couldn't avoid the trap and took damage!"
        },
        "skill_check": "Dexterity",  # Example skill required
        "difficulty": 12  # Skill check difficulty
    },
    "enemy": {
        "prompt": "An enemy appears! How do you want to handle this?",
        "options": {
            "1": "Fight",
            "2": "Try to negotiate"
        },
        "success_message": {
            "1": "You defeated the enemy!",
            "2": "You successfully negotiated with the enemy!"
        },
        "failure_message": {
            "1": "You were hurt in the fight!",
            "2": "The enemy refused your offer and attacked you!"
        },
        "skill_check": "Combat",  # Skill required
        "difficulty": 15
    },
    "puzzle": {
        "prompt": "You encountered a puzzle! Can you solve it?",
        "options": {
            "1": "Try to solve the puzzle",
            "2": "Ignore the puzzle and move on"
        },
        "success_message": {
            "1": "You solved the puzzle and gained some experience!",
            "2": "You moved on without solving the puzzle."
        },
        "failure_message": {
            "1": "You failed to solve the puzzle and wasted some energy.",
            "2": "You moved on but feel like you missed something important."
        },
        "skill_check": "Intelligence",
        "difficulty": 10
    }
}


def get_event_data(event_key):
    """Retrieve the event data based on the given event key."""
    return event_data.get(event_key, None)


def trigger_event(room_type, player_character, game_window):
    """Handle the event for a given room type."""
    event_info = get_event_data(room_type)

    if event_info:
        game_window.interactive_window.append(f"Event: {event_info['prompt']}")
        for option_key, option_text in event_info['options'].items():
            game_window.interactive_window.append(f"{option_key}. {option_text}")

        # Handle player's choice using QInputDialog
        command, ok = QInputDialog.getText(game_window, "Event Action",
                                           f"Choose an action (1 or 2) to handle the {room_type} event:")
        if ok and command in event_info['options']:
            success = perform_skill_check(player_character, event_info['skill_check'], event_info['difficulty'])
            if success:
                game_window.interactive_window.append(event_info["success_message"][command])
            else:
                game_window.interactive_window.append(event_info["failure_message"][command])
                # Apply some penalty or effect, e.g., reduce player health or energy
                player_character.health -= 10  # Example penalty
                game_window.update_character_sheet()
        else:
            game_window.interactive_window.append("Invalid choice. Event failed.")
            return False
        return True
    return False


def perform_skill_check(player_character, skill_name, difficulty):
    """Perform a skill check for the given skill against a difficulty level."""
    skill_value = player_character.skills.get(skill_name, 0)
    dice_roll = random.randint(1, 20)  # Roll a 20-sided die
    total = skill_value + dice_roll

    print(f"Skill Check: {skill_name} (Skill Value: {skill_value} + Roll: {dice_roll} = Total: {total})")

    return total >= difficulty

def skill_check(player_character, skill_name, difficulty):
    """Perform a skill check for the given skill against a difficulty level."""
    skill_value = player_character.skills.get(skill_name, 0)
    dice_roll = random.randint(1, 20)  # Roll a 20-sided die
    total = skill_value + dice_roll

    print(f"Skill Check: {skill_name} (Skill Value: {skill_value} + Roll: {dice_roll} = Total: {total})")

    return total >= difficulty
